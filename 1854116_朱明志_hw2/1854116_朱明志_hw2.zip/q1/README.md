# 运行环境

Python3.8.3
所依赖的包：
scipy
scikit-learn
matplotlib
numpy
pandas

# 运行方式

直接执行python.exe 运行脚本
